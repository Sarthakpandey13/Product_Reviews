import json2xml from 'json2xml';

export const convertLogsToXML = (jsonLogs) => {
  return json2xml(jsonLogs);
};
