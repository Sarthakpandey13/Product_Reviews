import { v4 as uuidv4 } from 'uuid';
const dynamoDB = new AWS.DynamoDB.DocumentClient();
import AWS from 'aws-sdk';


export const insertDynamoDB = async (event) => {

  try {

    console.log('Handling POST request');

    const data = JSON.parse(event.body);

    console.log('Parsed data:', data);



    data.review_id = uuidv4();



    const item = {

      TableName: process.env.DYNAMODB_TABLE_NAME,

      Item: data,

    };



    await dynamoDB.put(item).promise();

    console.log('Data inserted successfully');



    return {

      statusCode: 200,

      body: JSON.stringify({

        message: 'Data inserted successfully.',

        review_id: data.review_id,

      }),

    };

  } catch (err) {

    console.error('Error:', err);

    return {

      statusCode: 500,

      body: JSON.stringify(err.message),

    };

  }
};