import AWS from 'aws-sdk';
import { Builder } from 'xml2js';

const dynamoDb = new AWS.DynamoDB.DocumentClient();
const tableName = process.env.DYNAMODB_TABLE_NAME; // Ensure this environment variable is set

export const xmlDynamoDB = async (event) => {
    try {
        // Fetch data from DynamoDB
        const params = {
            TableName: tableName,
        };
        const data = await dynamoDb.scan(params).promise();
        const reviews = data.Items;

        // Convert data to XML format
        const xmlData = {
            feed: {
                $: {
                    'xmlns:vc': 'http://www.w3.org/2007/XMLSchema-versioning',
                    'xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
                    'xsi:noNamespaceSchemaLocation': 'http://www.google.com/shopping/reviews/schema/product/2.3/product_reviews.xsd'
                },
                version: '2.3',
                aggregator: {
                    name: 'Sample Reviews Aggregator (if applicable)',
                },
                publisher: {
                    name: 'Sample Retailer',
                    favicon: 'http://www.example.com/favicon.png',
                },
                reviews: {
                    review: reviews.map(review => ({
                        review_id: review.review_id,
                        reviewer: {
                            name: { _: review.reviewer_name || '', $: { is_anonymous: review.is_anonymous || false } },
                            reviewer_id: review.reviewer_id || '',
                        },
                        review_timestamp: review.review_timestamp || '',
                        title: review.title || '',
                        content: review.content || '',
                        pros: { pro: review.pros || [] },
                        cons: { con: review.cons || [] },
                        review_url: { _: review.review_url || '', $: { type: 'singleton' } },
                        reviewer_images: {
                            reviewer_image: Array.isArray(review.reviewer_images) ? review.reviewer_images.map(image => ({ url: image })) : [],
                        },
                        ratings: {
                            overall: { _: review.ratings_overall || '', $: { min: 1, max: 5 } },
                        },
                        products: {
                            product: {
                                product_ids: {
                                    gtins: { gtin: review.product_ids_gtin || [] },
                                    mpns: { mpn: review.product_ids_mpn || [] },
                                    skus: { sku: review.product_ids_sku || [] },
                                    brands: { brand: review.product_ids_brand || [] },
                                    asins: { asin: review.product_ids_asin || [] },
                                },
                                product_name: review.product_name || '',
                                product_url: review.product_url || '',
                            },
                        },
                        is_spam: review.is_spam || false,
                        collection_method: review.collection_method || '',
                        transaction_id: review.transaction_id || '',
                    })),
                },
            },
        };

        const builder = new Builder();
        const xml = builder.buildObject(xmlData);

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/xml' },
            body: xml,
        };
    } catch (error) {
        console.error('Error converting to XML:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal Server Error' }),
        };
    }
};








