const dynamoDB = new AWS.DynamoDB.DocumentClient();

import AWS from 'aws-sdk';


export const getReviewId = async (event) => {
  try {
    console.log('Handling GET request');
    const reviewerId = event.queryStringParameters.reviewer_id;
    console.log('Reviewer ID:', reviewerId);

    if (!reviewerId) {
      console.log('Missing reviewer_id in query parameters');
      return {
        statusCode: 400,
        body: JSON.stringify({
          message: 'Missing reviewer_id in query parameters.',
        }),
      };
    }

    const params = {
      TableName: process.env.DYNAMODB_TABLE_NAME,
      Key: { reviewer_id: reviewerId },
    };

    const response = await dynamoDB.get(params).promise();
    console.log('DynamoDB response:', response);

    if (!response.Item) {
      console.log('Data not found');
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'Data not found.' }),
      };
    }

    return {
      statusCode: 200,
      body: JSON.stringify(response.Item),
    };
  } catch (err) {
    console.error('Error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify(err.message),
    };
  }
};