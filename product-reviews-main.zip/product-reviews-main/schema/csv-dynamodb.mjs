import AWS from 'aws-sdk';
import csv from 'csv-parser'; // Ensure this package is installed
import { Readable } from 'stream';

const dynamoDB = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.DYNAMODB_TABLE_NAME; // Use the environment variable

export const uploadCSV = async (event) => {
    console.log('Incoming event:', JSON.stringify(event, null, 2)); // Log the incoming event

    const contentType = event.headers['Content-Type'] || event.headers['content-type'];
    if (!contentType) {
        console.error('Missing Content-Type header');
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Missing Content-Type header' }),
        };
    }

    // Decode the body if it is base64 encoded
    const buffer = event.isBase64Encoded ? Buffer.from(event.body, 'base64') : Buffer.from(event.body);
    const boundary = contentType.split('; ')[1]?.replace('boundary=', '');
    if (!boundary) {
        console.error('Invalid Content-Type format');
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Invalid Content-Type format' }),
        };
    }

    const parts = buffer.toString().split(`--${boundary}`);
    const results = [];

    return new Promise((resolve, reject) => {
        for (const part of parts) {
            if (part.includes('Content-Disposition')) {
                const contentDisposition = part.split('\r\n')[1];
                const filenameMatch = contentDisposition.match(/filename="([^"]+)"/);
                if (filenameMatch) {
                    const fileDataStartIndex = part.indexOf('\r\n\r\n') + 4;
                    const csvData = part.slice(fileDataStartIndex, -4); // Remove trailing '--\r\n'

                    // Parse CSV data
                    const readableStream = new Readable();
                    readableStream.push(csvData);
                    readableStream.push(null); // Signal the end of the stream

                    readableStream
                        .pipe(csv())
                        .on('data', (data) => {
                            console.log('Parsed CSV row:', data); // Log each CSV row
                            if (!data.reviewer_id || !data.review_id) {
                                console.error('Missing reviewer_id or review_id in data:', data);
                                return; // Skip this entry or handle as needed
                            }
                            results.push({
                                reviewer_id: data.reviewer_id, // Maps to reviewer_id
                                review_id: data.review_id, // Maps to review_id
                                aggregator_name: data.aggregator_name || '', // Maps to aggregator_name
                                publisher_name: data.publisher_name || '', // Maps to publisher_name
                                review_timestamp: data.review_timestamp || '', // Maps to review_timestamp
                                title: data.title || '', // Maps to title
                                content: data.content || '', // Maps to content
                                pros: data.pros || '', // Maps to pros
                                cons: data.cons || '', // Maps to cons
                                review_url: data.review_url || '', // Maps to review_url
                                reviewer_images: data.reviewer_images || '', // Maps to reviewer_images
                                ratings_overall: parseFloat(data.ratings_overall) || null, // Maps to ratings_overall
                                product_ids_gtin: data.product_ids_gtin || '', // Maps to product_ids_gtin
                                product_ids_mpn: data.product_ids_mpn || '', // Maps to product_ids_mpn
                                product_ids_sku: data.product_ids_sku || '', // Maps to product_ids_sku
                                product_ids_brand: data.product_ids_brand || '', // Maps to product_ids_brand
                                product_ids_asin: data.product_ids_asin || '', // Maps to product_ids_asin
                                product_name: data.product_name || '', // Maps to product_name
                                product_url: data.product_url || '', // Maps to product_url
                                is_spam: data.is_spam === 'TRUE', // Convert string to boolean for is_spam
                                collection_method: data.collection_method || '', // Maps to collection_method
                                transaction_id: data.transaction_id || '', // Maps to transaction_id
                                email: data.email || '', // Maps to email
                            });
                        })
                        .on('end', async () => {
                            try {
                                console.log('CSV parsing completed, results:', results);
                                const putRequests = results.map((item) => ({
                                    PutRequest: {
                                        Item: item,
                                    },
                                }));

                                for (let i = 0; i < putRequests.length; i += 25) {
                                    const batch = putRequests.slice(i, i + 25);
                                    await dynamoDB
                                        .batchWrite({ RequestItems: { [TABLE_NAME]: batch } })
                                        .promise();
                                }

                                console.log('Data successfully inserted into DynamoDB');
                                resolve({
                                    statusCode: 200,
                                    body: JSON.stringify({ message: 'CSV data uploaded successfully', count: results.length }),
                                });
                            } catch (error) {
                                console.error('Error inserting data into DynamoDB:', error);
                                reject({
                                    statusCode: 500,
                                    body: JSON.stringify({ message: 'Internal server error' }),
                                });
                            }
                        })
                        .on('error', (error) => {
                            console.error('Error parsing CSV:', error);
                            reject({
                                statusCode: 500,
                                body: JSON.stringify({ message: 'Error parsing CSV' }),
                            });
                        });
                }
            }
        }
    });
};







