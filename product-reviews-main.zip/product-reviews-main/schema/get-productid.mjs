
const dynamoDB = new AWS.DynamoDB.DocumentClient();

import AWS from 'aws-sdk';

export const getProductId = async (event) => {
  try {
    console.log('Handling GET request for MPN');
    const productIdsMpn = event.queryStringParameters.product_ids_mpn;
    console.log('Product IDs MPN:', productIdsMpn);

    if (!productIdsMpn) {
      console.log('Missing product_ids_mpn in query parameters');
      return {
        statusCode: 400,
        body: JSON.stringify({
          message: 'Missing product_ids_mpn in query parameters.',
        }),
      };
    }

    const params = {
      TableName: process.env.DYNAMODB_TABLE_NAME,
      IndexName: 'product_ids_mpn-index',
      KeyConditionExpression: 'product_ids_mpn = :product_ids_mpn',
      ExpressionAttributeValues: {
        ':product_ids_mpn': productIdsMpn,
      },
    };

    const response = await dynamoDB.query(params).promise();
    console.log('DynamoDB response:', response);

    return {
      statusCode: 200,
      body: JSON.stringify(response.Items),
    };
  } catch (err) {
    console.error('Error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify(err.message),
    };
  }
};