
import AWS from 'aws-sdk';
const dynamoDB = new AWS.DynamoDB.DocumentClient();



export const updateDynamoDB = async (event) => {
  try {
    console.log('Handling UPDATE request');
    const data = JSON.parse(event.body);
    console.log('Parsed data:', data);

    const params = {
      TableName: process.env.DYNAMODB_TABLE_NAME,
      Key: { reviewer_id: data.reviewer_id },
      UpdateExpression: 'set #attrName = :attrValue',
      ExpressionAttributeNames: { '#attrName': 'yourAttributeName' },
      ExpressionAttributeValues: { ':attrValue': 'yourAttributeValue' },
      ReturnValues: 'UPDATED_NEW',
    };

    const response = await dynamoDB.update(params).promise();
    console.log('Data updated successfully', response);

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Data updated successfully.',
      }),
    };
  } catch (err) {
    console.error('Error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify(err.message),
    };
  }
};
