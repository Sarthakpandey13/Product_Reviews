
const dynamoDB = new AWS.DynamoDB.DocumentClient();

import AWS from 'aws-sdk';


export const putDynamoDB = async (event) => {
  try {
    console.log('Handling PUT request');
    const data = JSON.parse(event.body);
    console.log('Parsed data:', data);

    const params = {
      TableName: process.env.DYNAMODB_TABLE_NAME,
      Item: data,
    };

    await dynamoDB.put(params).promise();
    console.log('Data inserted/updated successfully');

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Data inserted/updated successfully.',
      }),
    };
  } catch (err) {
    console.error('Error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify(err.message),
    };
  }
};